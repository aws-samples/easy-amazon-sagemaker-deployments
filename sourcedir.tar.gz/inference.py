# Meta uses model package ARN to deploy, not Model Hub scripts
